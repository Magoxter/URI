#include <stdio.h>
 
int main() {
    
    double  pi = 3.14159,
            area,
            raio;
    
    scanf ("%lf", &raio);
    
    area = pi * (pow(raio,2));
    
    printf ("A=%.4lf", area);
    printf ("\n");
 
    return 0;
}
