#include <stdio.h>
 
int main () {
    
    int a,b;
    int soma;
    
    scanf ("%d", &a);
    scanf ("%d", &b);

    soma = a + b;
    
    printf ("SOMA = %d\n", soma);
        
    return 0;
}
