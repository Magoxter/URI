#include <stdio.h>
 
int main (void) {
    
    int num1,
        num2;
    int PROD;
    
 scanf ("%d", &num1);
 scanf ("%d", &num2);
    
    PROD = num1 * num2;
    
    printf ("PROD = %d", PROD);
    printf ("\n");
    
    return 0;
}
