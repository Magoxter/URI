	/* Salario */
#include <stdio.h>

int main (void) {
  int 	func,
  	  	horas;
  float valor,
  		salario;
  	scanf("%d", &func);
  	scanf("%d", &horas);
  	scanf("%f", &valor);
  salario = valor*horas;
   printf("NUMBER = %d\n", func);
   printf("SALARY = U$ %.2f\n", salario);
 return 0;
}
