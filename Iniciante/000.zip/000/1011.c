	/* Esfera */
#include <stdio.h>
#include <math.h>

int main (void) {
  int    raio;
  double volume,
        pi;
      pi = 3.14159;
    scanf("%d", &raio);
  volume = (4/3.0)*pi*raio*raio*raio;
   printf("VOLUME = %.3lf\n", volume);
 return 0;
}
