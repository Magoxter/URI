    /* Distancia */
#include <stdio.h>

int main (void) {
  int X,km,
      dist,
      min;
    scanf("%d", &km);
   min = 2;
   dist = km * min;
    printf("%d minutos\n", dist);
 return 0;
}
