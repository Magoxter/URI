	/* Combustivel */
#include <stdio.h>

int main (void) {
  float litros;
  int	quilometragem,
  		horas,distancia;
  	scanf("%d", &horas);
  	scanf("%d", &quilometragem);
  distancia = quilometragem * horas;
  litros = distancia / 12.0;
   printf("%.3f\n", litros);
 return 0;
}
