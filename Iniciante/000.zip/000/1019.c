    /* Tempo */
#include <stdio.h>
#define HORA 3600
#define MINUTO 60

int main (void) {
  int tempo,
      horas,
      minutos,
      segundos;
    scanf("%d", &tempo);
   horas = (tempo/HORA);
   minutos = (tempo -(horas*HORA))/MINUTO;
   segundos = (tempo -(horas*HORA)-(minutos*MINUTO));
    printf("%d:%d:%d\n", horas,minutos,segundos);
 return 0;
}
