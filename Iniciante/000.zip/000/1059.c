	/* Pares */
#include <stdio.h>

int main (void) {
  int n,i;
  	n = 100;
  for (i = 1; i <= n; i++)
   if (i % 2 == 0)
  	 printf("%d\n", i);
 return 0;
}
