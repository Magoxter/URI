    /* Seq IJ 1 */
#include <stdio.h>

int main (void) {
  int i,j;
   i = -2;
   j = 65;
 while (j-5 >= 0) {
   i+=3;
   j-=5;
  printf("I=%d J=%d\n", i, j);
 }
 return 0;
}
