#include<stdio.h>

int main (void)
{
    int p, j1, j2, r, a;
    int num, g;
    scanf("%d %d %d %d %d", &p, &j1, &j2, &r, &a);
    num=(j1+j2)%2;
    if((p==1)^(num==0))
        g=2;
        else
            g=1;
    if(r==1&&a==1)
        g=2;
        else if(r==0&&a==1)
            g=1;
        else if(r==1&&a==0)
            g=1;

printf("Jogador %d ganha!\n", g);
    return 0;
}
